const version = require("./package.json").version;

module.exports = {
  publicPath: "/",
  outputDir: "../dist/" + version,
  css: {
    extract:
      process.env.NODE_ENV != "production"
        ? false
        : {
            filename: "css/[name].[chunkhash].vw.css?version=" + version,
            chunkFilename: "css/[name].[chunkhash].vw.css?version=" + version
          }
  },
  chainWebpack: config => {
    config.output
      .filename("[name].[hash:8].js?version=" + version)
      .chunkFilename("[name].[hash:8].js?version=" + version);
    config.module
      .rule("images")
      .use("url-loader")
      .tap(() => ({
        name: "./img/[name].[hash:8].[ext]?version=" + version,
        quality: 85,
        limit: 0,
        esModule: false
      }));
    config.module
      .rule("fonts")
      .use("url-loader")
      .tap(() => ({
        name: "./fonts/[name].[hash:8].[ext]?version=" + version,
        quality: 85,
        limit: 0,
        esModule: false
      }));
  }
}