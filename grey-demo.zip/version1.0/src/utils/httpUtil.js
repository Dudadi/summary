import axios from "axios";
import Util from "./commonUtil";

// ajax 请求统一处理 request

axios.defaults.baseURL = "/";
axios.defaults.timeout = 10000;
axios.defaults.withCredentials = true;
axios.interceptors.request.use(
  config => {
    const tid = Util.randomTransactionId(10);
    config.headers["x-request-id"] = tid;

    let version = sessionStorage.getItem("version");
    if (version) {
      config.headers["version"] = version;
    }

    return config;
  }
);

// ajax 请求统一处理 response
axios.interceptors.response.use(
  response => {
    // 统一错误码处理
    console.log(response)
    return response.data;
  }
);

export default axios;
