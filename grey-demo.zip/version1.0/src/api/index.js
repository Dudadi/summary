import HTTP from "@/utils/httpUtil";

// 加载 api 模块
const api = {};
const apiFiles = require.context("@/api", false, /\.js$/);
apiFiles.keys().forEach(fileName => {
  let file = apiFiles(fileName);
  let apiName = fileName.replace(/^\.\//, "").replace(/\.\w+$/, "");
  if (apiName != "index") {
    api[apiName] = file.default(HTTP);
  }
});

// 导出 api
export default {
  install(Vue) {
    Vue.prototype.$api = api;
  }
};
