export default function(http) {
  return {
    // 获取环境变量信息
    response(params) {
      return http.post("/api", params);
    }
  };
}
