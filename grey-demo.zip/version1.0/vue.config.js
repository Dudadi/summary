const path = require("path");
const version = require("./package.json").version;
const isMock = process.env.MOCK;
module.exports = {
  publicPath: "/",
  outputDir: "../dist/" + version,
  css: {
    extract:
      process.env.NODE_ENV != "production"
        ? false
        : {
            filename: "css/[name].[chunkhash].vw.css?version=" + version,
            chunkFilename: "css/[name].[chunkhash].vw.css?version=" + version
          }
  },
  chainWebpack: config => {
    config.output
      .filename("[name].[hash:8].js?version=" + version)
      .chunkFilename("[name].[hash:8].js?version=" + version);
    config.module
      .rule("images")
      .use("url-loader")
      .tap(() => ({
        name: "./img/[name].[hash:8].[ext]?version=" + version,
        quality: 85,
        limit: 0,
        esModule: false
      }));
    config.module
      .rule("fonts")
      .use("url-loader")
      .tap(() => ({
        name: "./fonts/[name].[hash:8].[ext]?version=" + version,
        quality: 85,
        limit: 0,
        esModule: false
      }));
  },
  devServer: {
    host: "localhost",
    port: "8080",
    before:
      isMock == "true"
        ? require("./mocks/mock-server.js")(
            path.resolve(__dirname, "./mocks/api"),
            require("body-parser")
          )
        : "",
    historyApiFallback: {
      verbose: true,
      rewrites: [
        {
          from: /^\/pageA.*$/,
          to: "/pageA.html"
        },
        {
          from: /^\/pageB.*$/,
          to: "/pageB.html"
        }
      ]
    },
    proxy: {
      "/A": {
        target: "http://127.0.0.1:8088",
        changeOrigin: true,
        secure: false,
      },
      "/B": {
        // 开发环境IP
        target: "http://127.0.0.1:8089",
        changeOrigin: true,
        secure: false
      }
    },
    hot: true
  }
}