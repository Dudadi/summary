/* eslint-disable */
const chokidar = require("chokidar");

/**
 * mock server
 *
 * @param {*} mocks [{ method, url, reponse }]
 * @param {*} app express app
 */
function registerRoutes(mocks, app, bodyParser) {
  console.log(
    "register routes",
    mocks.map(v => `${v.method || "post"} ${v.url}`)
  );

  const jsonBodyParser = bodyParser.json();
  let mockLastIndex;
  let mockRoutesLength = 0;

  (mocks || []).forEach(({ method, url, response }) => {
    const handler = (req, res) => {
      const data = typeof response === "function" ? response(req) : response;
      console.log("response", method, url);
      res.json(data);
    };

    app[method || "post"](new RegExp(url), jsonBodyParser, handler);
    mockLastIndex = app._router.stack.length;
    mockRoutesLength++;
  });

  return {
    mockRoutesLength,
    mockStartIndex: mockLastIndex - mockRoutesLength
  };
}

function unregisterRoutes(mocksDir) {
  Object.keys(require.cache).forEach(i => {
    if (i.includes(mocksDir)) {
      delete require.cache[require.resolve(i)];
    }
  });
}

module.exports = (mocksDir, bodyParser) => app => {
  app.use(bodyParser.urlencoded({ extended: true }));

  const mocks = require(mocksDir);
  let { mockStartIndex, mockRoutesLength } = registerRoutes(
    mocks,
    app,
    bodyParser
  );

  // watch files, hot reload mock server
  chokidar
    .watch(mocksDir, {
      ignoreInitial: true
    })
    .on("all", (event, path) => {
      if (event === "change" || event === "add") {
        try {
          app._router.stack.splice(mockStartIndex, mockRoutesLength);
          unregisterRoutes(mocksDir);

          const mockRoutes = registerRoutes(mocks, app, bodyParser);
          mockRoutesLength = mockRoutes.mockRoutesLength;
          mockStartIndex = mockRoutes.mockStartIndex;

          console.log(`Mock Server hot reload success! changed  ${path}`);
        } catch (error) {
          console.log(`Mock Server hot reload error:  ${path}`);
        }
      }
    });
};
