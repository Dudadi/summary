module.exports = [
  {
    url: "/api",
    response() {
      return {
        resultCode: 0,
        resultDesc: "success",
        msg: "I am server,how are you?"
      }
    }
  }
]