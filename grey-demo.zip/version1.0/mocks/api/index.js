const Test = require("./test");
module.exports = [
  ...Test
];
